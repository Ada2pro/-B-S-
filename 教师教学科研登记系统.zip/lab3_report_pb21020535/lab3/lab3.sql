-- Active: 1717915618627@@127.0.0.1@3306@lab3
CREATE TABLE IF NOT EXISTS teachers (
    id CHAR(5)  PRIMARY KEY,
    name VARCHAR(256),
    gender SMALLINT CHECK (gender IN (1, 2)),
    title SMALLINT  CHECK (title IN (1, 2,3,4,5,6,7,8,9,10,11))
    /* INDEX (title_id) */
);
CREATE TABLE IF NOT EXISTS admins(
    id VARCHAR(50) PRIMARY KEY,
    pwd VARCHAR(256)
);
INSERT into admins values('admin','admin');
CREATE TABLE IF NOT EXISTS papers (
    id INT PRIMARY KEY,
    name VARCHAR(256),
    source VARCHAR(256),
    time DATE,
    type SMALLINT CHECK (type IN (1, 2, 3, 4)),
    level SMALLINT CHECK (level IN (1, 2, 3, 4, 5,6))
);

CREATE TABLE IF NOT EXISTS projects (
    id VARCHAR(256) PRIMARY KEY,
    name VARCHAR(256),
    source VARCHAR(256),
    type SMALLINT CHECK (type IN (1, 2, 3, 4,5)),
    total_funds FLOAT,
    start_year INT,
    end_year INT
);

CREATE TABLE IF NOT EXISTS courses (
    id VARCHAR(256) PRIMARY KEY,
    name VARCHAR(255),
    total_hours INT,
    type int check (type in (1, 2))
);

CREATE TABLE IF NOT EXISTS publish_papers (
    teacher_id CHAR(5),
    paper_id INT,
    ranking int,
    corresponding_author BOOLEAN,
    PRIMARY KEY (teacher_id, paper_id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(id),
    FOREIGN KEY (paper_id) REFERENCES papers(id)
);


CREATE TABLE IF NOT EXISTS manage_projects(
    teacher_id CHAR(5),
    project_id VARCHAR(256),
    ranking int,
    funds FLOAT,
    PRIMARY KEY (teacher_id, project_id),
    FOREIGN KEY (teacher_id) REFERENCES teachers(id),
    FOREIGN KEY (project_id) REFERENCES projects(id)
);



DROP TABLE IF EXISTS teach_courses;
CREATE TABLE IF NOT EXISTS teach_courses(
    teacher_id CHAR(5),
    course_id VARCHAR(256),
    year int,
    semester SMALLINT check (semester in (1, 2, 3)),
    hours int,
    PRIMARY KEY (teacher_id, course_id, year, semester),
    FOREIGN KEY (teacher_id) REFERENCES teachers(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE DATABASE IF NOT EXISTS lab3_5;

SELECT CONSTRAINT_NAME, CHECK_CLAUSE
FROM information_schema.CHECK_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = 'lab3';

/* 删除触发器 */
DROP TRIGGER IF EXISTS check_corresponding_author_before_update;



-- Create trigger to check for multiple corresponding authors per paper
DELIMITER //

CREATE TRIGGER check_corresponding_author_before_insert
BEFORE INSERT ON publish_papers
FOR EACH ROW
BEGIN
    DECLARE num_corresponding_authors INT;
    
    SELECT COUNT(*) INTO num_corresponding_authors
    FROM publish_papers
    WHERE paper_id = NEW.paper_id AND corresponding_author = 1;
    
    IF num_corresponding_authors = 1 and NEW.corresponding_author=1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one corresponding author allowed per paper';
    END IF;
END //

CREATE TRIGGER check_corresponding_author_before_update
BEFORE UPDATE ON publish_papers
FOR EACH ROW
BEGIN
    DECLARE num_corresponding_authors INT;
    
    SELECT COUNT(*) INTO num_corresponding_authors
    FROM publish_papers
    WHERE paper_id = NEW.paper_id AND corresponding_author = 1 AND OLD.corresponding_author!=1;
    
    IF num_corresponding_authors > 0 and NEW.corresponding_author=1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one corresponding author allowed per paper';
    END IF;
END //

DELIMITER ;
DROP TRIGGER IF EXISTS check_corresponding_author_before_update;


DELIMITER //

CREATE TRIGGER check_author_rank_before_insert
BEFORE INSERT ON publish_papers
FOR EACH ROW
BEGIN
    DECLARE num_author_ranks INT;
    
    SELECT COUNT(*) INTO num_author_ranks
    FROM publish_papers
    WHERE paper_id = NEW.paper_id AND ranking = NEW.ranking;
    
    IF num_author_ranks > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Author rank must be unique per paper';
    END IF;
END //

CREATE TRIGGER check_author_rank_before_update
BEFORE UPDATE ON publish_papers
FOR EACH ROW
BEGIN
    DECLARE num_author_ranks INT;
    
    SELECT COUNT(*) INTO num_author_ranks
    FROM publish_papers
    WHERE paper_id = NEW.paper_id AND ranking = NEW.ranking;
    
    IF num_author_ranks > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Author rank must be unique per paper';
    END IF;
END //

DELIMITER ;


-- Create trigger to check for valid paper type and level
-- Add import statements for SQL statements used in triggers


/* 删除触发器 */



-- 更改 DELIMITER
DELIMITER //

-- 插入操作触发器
CREATE TRIGGER check_ranking_before_insert
BEFORE INSERT ON manage_projects
FOR EACH ROW
BEGIN
    DECLARE num_rankings INT;
    
    -- 计算同一项目中具有相同排名的记录数
    SELECT COUNT(*) INTO num_rankings
    FROM manage_projects
    WHERE project_id = NEW.project_id AND ranking = NEW.ranking;
    
    -- 如果有相同排名，触发错误
    IF num_rankings > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ranking must be unique within a project';
    END IF;
END //

-- 更新操作触发器
CREATE TRIGGER check_ranking_before_update
BEFORE UPDATE ON manage_projects
FOR EACH ROW
BEGIN
    DECLARE num_rankings INT;
    
    -- 计算同一项目中具有相同排名的记录数（排除当前正在更新的记录）
    SELECT COUNT(*) INTO num_rankings
    FROM manage_projects
    WHERE project_id = NEW.project_id AND ranking = NEW.ranking;
    
    -- 如果有相同排名，触发错误
    IF num_rankings > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ranking must be unique within a project';
    END IF;
END //

-- 恢复默认 DELIMITER
DELIMITER ;


DROP TRIGGER IF EXISTS update_total_hours_after_delete


/* 查看触发器有哪些 */
-- View triggers
SELECT TRIGGER_NAME, EVENT_OBJECT_TABLE, ACTION_TIMING, ACTION_STATEMENT
FROM information_schema.TRIGGERS
WHERE TRIGGER_SCHEMA = 'lab3';



