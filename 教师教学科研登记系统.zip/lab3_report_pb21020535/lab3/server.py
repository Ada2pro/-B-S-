from flask import Flask, request, render_template, redirect, url_for, session,jsonify
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app)
app.secret_key = 'your_secret_key'  

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="666",
    database="lab3"
)
cursor = db.cursor(dictionary=True)
@app.route('/')
def home():
        return redirect(url_for('login')) 



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
         
        cursor.execute("SELECT * FROM admins WHERE id = %s AND pwd= %s", (username, password))
        admin = cursor.fetchone()
        if admin:
            session['logged_in'] = True
            return redirect(url_for('admin_panel'))
        else:
            return 'Invalid Credentials'
    return render_template('login.html')



@app.route('/admin_panel')
def admin_panel():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('admin_panel.html') 


@app.route('/paper')
def paper():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('paper.html') 


@app.route('/project')
def project():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('project.html') 

@app.route('/publish_papers')
def publish_papers():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('publish_papers.html') 


@app.route('/manage_projects')
def manage_projects():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('manage_projects.html') 


@app.route('/teach_courses')
def teach_courses():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('teach_courses.html') 

@app.route('/add_paper', methods=['POST'])
def add_paper():
    data = request.json
    query = """
    INSERT INTO papers (id, name, source, time, type, level)
    VALUES (%s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (data['paper_id'], data['paper_name'], data['paper_source'], data['paper_time'], data['paper_type'], data['paper_level']))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/delete_paper', methods=['POST'])
def delete_paper():
    data = request.json
    query = "DELETE FROM papers WHERE id = %s"
    cursor.execute(query, (data['paper_id'],))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/update_paper', methods=['POST'])
def update_paper():
    data = request.json
    query = """
    UPDATE papers
    SET id = %s, name = %s, source = %s, time = %s, type = %s, level = %s
    WHERE id = %s
    """
    cursor.execute(query, (data['new_id'], data['new_name'], data['new_source'], data['new_time'], data['new_type'], data['new_level'], data['old_id']))
    db.commit()
    print(data)
    return jsonify({'status': 'success', 'data': data})

@app.route('/query_paper', methods=['GET'])
def query_paper():
    query_param = request.args.get('query')
    query = """
    SELECT * FROM papers
    WHERE id = %s OR name LIKE %s
    """
    cursor.execute(query, (query_param, f"%{query_param}%"))
    result = cursor.fetchall()
    return jsonify({'status': 'success', 'data': result})
    




@app.route('/add_project', methods=['POST'])
def add_project():
    data = request.json
    query = """
    INSERT INTO projects (id,name, source,type, total_funds, start_year, end_year)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    cursor.execute(query, (data['project_id'], data['project_name'], data['project_source'], data['project_type'], data['project_total_funds'], data['project_start_time'], data['project_end_time']))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/delete_project', methods=['POST'])
def delete_project():
    data = request.json
    query = "DELETE FROM projects WHERE id = %s"
    cursor.execute(query, (data['project_id'],))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/update_project', methods=['POST'])
def update_project():
    data = request.json
    query = """
    UPDATE projects
    SET id = %s,name = %s, source = %s,type = %s, total_funds = %s, start_year = %s, end_year = %s
    WHERE id = %s
    """
    cursor.execute(query, (data['new_id'], data['new_name'], data['new_source'], data['new_time'], data['new_type'], data['new_level'], data['new_le'], data['old_id']))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/query_project', methods=['GET'])
def query_project():
    query_param = request.args.get('query')
    query = """
    SELECT * FROM projects
    WHERE id = %s OR name LIKE %s
    """
    cursor.execute(query, (query_param, f"%{query_param}%"))
    result = cursor.fetchall()
    return jsonify({'status': 'success', 'data': result})






@app.route('/add_paper_info', methods=['POST'])
def add_paper_info():
    data = request.json
    query = """
    INSERT INTO publish_papers (teacher_id, paper_id, ranking, corresponding_author)
    VALUES (%s, %s, %s, %s)
    """
    cursor.execute(query, (data['teacher_id'], data['paper_id'], data['paper_ranking'], data['paper_coauthor']))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/delete_paper_info', methods=['POST'])
def delete_paper_info():
    data = request.json
    query = "DELETE FROM publish_papers WHERE teacher_id = %s AND paper_id = %s"
    cursor.execute(query, (data['teacher_id'], data['paper_id']))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/update_paper_info', methods=['POST'])
def update_paper_info():
    data = request.json
    query = """
    UPDATE publish_papers
    SET teacher_id = %s, paper_id = %s, ranking = %s, corresponding_author = %s
    WHERE teacher_id = %s AND paper_id = %s
    """
    cursor.execute(query, (data['new_teacher_id'], data['new_paper_id'], data['new_paper_ranking'], data['new_paper_coauthor'], data['old_teacher_id'], data['old_paper_id']))
    db.commit()
    return jsonify({'status': 'success', 'data': data})

@app.route('/query_paper_info', methods=['GET'])
def query_paper_info():
    query_param = request.args.get('query')
    query = """
    SELECT * FROM publish_papers
    WHERE teacher_id = %s
    """
    cursor.execute(query, (query_param,))
    result = cursor.fetchall()
    return jsonify({'status': 'success', 'data': result})


@app.route('/project_info', methods=['GET'])
def get_project_info():
    project_id = request.args.get('project_id')

    cursor.execute("SELECT * FROM manage_projects WHERE project_id = %s", (project_id,))
    allocations = cursor.fetchall()

    cursor.execute("SELECT total_funds FROM projects WHERE id = %s", (project_id,))
    project = cursor.fetchone()
    print(project)
    if not project:
        return jsonify({'error': 'Project not found'}), 404

    return jsonify({'success': True, 'total_funding': project['total_funds'], 'allocations': allocations}), 200

@app.route('/modify_project_info', methods=['POST'])
def modify_project_info():
    data = request.json
    project_id = data.get('project_id')
    total_funding = data.get('total_funding')
    allocations = data.get('allocations')

  
    allocated_funding = sum(float(allocation['project_funding']) for allocation in allocations)

    if allocated_funding != float(total_funding):
        return jsonify({'error': 'Total allocated funding does not match project total funding'}), 400

    cursor.execute("UPDATE projects SET total_funds = %s WHERE id = %s", (total_funding, project_id))

    cursor.execute("DELETE FROM manage_projects WHERE project_id = %s", (project_id,))
    for allocation in allocations:
        cursor.execute(
            "INSERT INTO manage_projects (teacher_id, project_id, ranking, funds) VALUES (%s, %s, %s, %s)",
            (allocation['teacher_id'], project_id, allocation['project_ranking'], allocation['project_funding'])
        )

    db.commit()

    return jsonify({'success': True}), 200


@app.route('/teacher_projects', methods=['GET'])
def get_teacher_projects():
    teacher_id = request.args.get('teacher_id')

    cursor.execute("""
        SELECT pa.project_id, pa.ranking, pa.funds, p.total_funds
        FROM manage_projects pa
        JOIN projects p ON pa.project_id = p.id
        WHERE pa.teacher_id = %s
    """, (teacher_id,))
    projects = cursor.fetchall()

    if not projects:
        return jsonify({'error': 'No projects found for the specified teacher'}), 404

    return jsonify({'success': True, 'projects': projects}), 200




@app.route('/course_info', methods=['GET'])
def get_course_info():
    course_id = request.args.get('course_id')
    year = request.args.get('year')
    semester = request.args.get('semester')

    
    cursor.execute("SELECT * FROM courses WHERE id = %s", (course_id,))
    course = cursor.fetchone()

    if not course:
        return jsonify({'error': 'Course not found'}), 404

   
    cursor.execute("SELECT * FROM teach_courses WHERE course_id = %s AND year = %s AND semester = %s", (course_id, year, semester))
    teachers = cursor.fetchall()

    return jsonify({'success': True, 'total_hours': course['total_hours'], 'teachers': teachers}), 200

@app.route('/modify_course_info', methods=['POST'])
def modify_course_info():
    data = request.json
    course_id = data.get('course_id')
    year = data.get('year')
    semester = data.get('semester')
    total_hours = data.get('total_hours')
    teachers = data.get('teachers')

 
    total_teaching_hours = sum(float(teacher['teaching_hours']) for teacher in teachers)

    if total_teaching_hours != float(total_hours):
        return jsonify({'error': 'Total teaching hours does not match course total hours'}), 400

    cursor.execute("UPDATE courses SET total_hours = %s WHERE id = %s", (total_hours, course_id))

    cursor.execute("DELETE FROM teach_courses WHERE course_id = %s AND year = %s AND semester = %s", (course_id, year, semester))
    for teacher in teachers:
        cursor.execute(
            "INSERT INTO teach_courses (teacher_id, course_id, year, semester, hours) VALUES (%s, %s, %s, %s, %s)",
            (teacher['teacher_id'], course_id, year, semester, teacher['teaching_hours'])
        )

    db.commit()

    return jsonify({'success': True}), 200

@app.route('/teacher_courses', methods=['GET'])
def get_teacher_courses():
    teacher_id = request.args.get('teacher_id')

    cursor.execute("""
        SELECT tc.course_id, tc.hours, c.total_hours, tc.year, tc.semester
        FROM teach_courses tc
        JOIN courses c ON tc.course_id = c.id
        WHERE tc.teacher_id = %s
    """, (teacher_id,))
    courses = cursor.fetchall()

    if not courses:
        return jsonify({'error': 'No courses found for the specified teacher'}), 404

    return jsonify({'success': True, 'courses': courses}), 200



@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))


@app.route('/query_teaching_research', methods=['GET'])
def query_teaching_research():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('query_teaching_research.html') 



@app.route('/query_teaching_research_', methods=['GET'])
def query_teaching_research_():
    teacher_id = request.args.get('teacher_id')
    start_year = request.args.get('start_year')
    end_year = request.args.get('end_year')

   
    teaching_query = """
    SELECT * FROM teach_courses
    WHERE teacher_id = %s AND year BETWEEN %s AND %s
    """
    cursor.execute(teaching_query, (teacher_id, start_year, end_year))
    teaching_results = cursor.fetchall()

    
    research_query = """
    SELECT * FROM manage_projects JOIN projects ON manage_projects.project_id = projects.id
    WHERE teacher_id = %s AND (
        projects.start_year BETWEEN %s AND %s OR
        projects.end_year BETWEEN %s AND %s OR
        (projects.start_year <= %s AND projects.end_year >= %s)
    )
    """
    cursor.execute(research_query, (teacher_id, start_year, end_year, start_year, end_year, start_year, end_year))
    research_results = cursor.fetchall()

    
    paper_query = """
    SELECT p.name AS paper_title, p.source AS publication, YEAR(p.time) AS year, pp.ranking, pp.corresponding_author
    FROM publish_papers pp
    JOIN papers p ON pp.paper_id = p.id
    WHERE pp.teacher_id = %s AND YEAR(p.time) BETWEEN %s AND %s
    """
    cursor.execute(paper_query, (teacher_id, start_year, end_year))
    paper_results = cursor.fetchall()

    result = {
        'teaching': teaching_results,
        'research': research_results,
        'papers': paper_results
    }

    return jsonify({'status': 'success', 'data': result})



if __name__ == '__main__':
    app.run(debug=True)
